package com.example.whatsapp.ui;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.example.whatsapp.R;
import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {
   TabLayout tablayout;
   ViewPager view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        tablayout.setupWithViewPager(view);
        adapFrag adap=new adapFrag(getSupportFragmentManager());
        adap.addfrag(new frag1(),"Chats");
        adap.addfrag(new frag2(),"Status");
        adap.addfrag(new frag3(),"Calls");
        view.setAdapter(adap);

    }
    private void init(){
        tablayout= findViewById(R.id.tab);
        view= findViewById(R.id.view);
      }
}